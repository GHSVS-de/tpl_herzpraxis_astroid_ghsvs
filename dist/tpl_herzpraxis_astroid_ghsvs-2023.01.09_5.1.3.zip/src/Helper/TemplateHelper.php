<?php
namespace GHSVS\Template\HerzpraxisAstroidGhsvs\Site\Helper;

\defined('_JEXEC') or die;

abstract class TemplateHelper
{
  public static function Test() {
    return 'Test Template\HerzpraxisAstroidGhsvs';
  }
}
